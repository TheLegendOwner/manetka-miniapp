'use client';
import React from 'react';

export default function NftsPage() {
  return (
    <div className="p-4 max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-4">NFTs</h2>
      <p>NFT collection placeholder.</p>
    </div>
  );
}
