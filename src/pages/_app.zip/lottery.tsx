'use client';
import React from 'react';

export default function LotteryPage() {
  return (
    <div className="p-4 max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-4">Lottery</h2>
      <p>Lottery tickets placeholder.</p>
    </div>
  );
}
